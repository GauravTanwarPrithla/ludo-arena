# Ludo Arena Mobile — Complete Offline Build (v1.0)

This is a native Android project intended to be built from a phone using a compatible Android IDE or through the included GitHub Actions workflow. It includes two apps:
- **Ludo Arena Player**: local 4-player pass-and-play prototype with dice, tokens, home lanes, capture, safe cells, six extra turn, and win detection.
- **Ludo Arena Controller**: a separate test controller that can queue dice values to the Player app only when both apps are signed with the same certificate and Player's Private Test Mode is enabled.

## Build APK from a phone without a PC (cloud build)
1. Download and extract this ZIP on your phone.
2. In a browser, create a GitHub repository.
3. Upload the extracted project files to the repository (GitHub mobile website may allow uploading files; if folder upload is awkward, use a phone Git client or upload the ZIP then extract it in a cloud workspace).
4. The included workflow `.github/workflows/build-apks.yml` runs on GitHub Actions.
5. Open the repository's **Actions** tab, run **Build Android APKs**, then download the artifact named `ludo-arena-apks`.
6. Extract the artifact; install `player-debug.apk` and `controller-debug.apk` on the same Android phone.

## Local build (Android IDE that supports Gradle Android projects)
Use JDK 17 and Android SDK Platform 35. From the project root:
`gradle :player:assembleDebug :controller:assembleDebug`

## Use the apps
1. Install both APKs from the same workflow run.
2. Open Ludo Arena and tap **Enable Private Test Mode** only when testing.
3. Open Ludo Arena Controller, select a value, and tap **QUEUE TEST DICE**.
4. Return to the Player app and tap **ROLL DICE**. The queued test value is used once.
5. Tap one of the current player's tokens to move it.

## Current scope / honest limitations
- This version is a playable **offline pass-and-play** game on one phone. It does not yet include online matchmaking, accounts, coins, friends, ads, or a hosted multiplayer service.
- Controller commands use an Android signature-level permission. The apps must be built/signed together and installed from the same build output for the controller integration to work.
- Ludo rule variants differ. This is a functional prototype, not a certified reproduction of any specific commercial game's exact rules.
- Public games must use server-generated randomness; forced dice are limited to clearly disclosed private testing.
