package com.ludoarena.player;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    static MainActivity active;
    static int pendingTestDice = 0;

    LinearLayout root, header, controls;
    TextView status, diceText, modeText;
    Button rollButton, resetButton, modeButton;
    BoardView board;
    int[] positions = new int[16]; // -1 home, 0..51 track-relative, 52..57 home lane, 58 finished
    int currentPlayer = 0, dice = 1;
    boolean rolled = false, testMode = false, gameOver = false;
    boolean[] finished = new boolean[4];
    Random random = new Random();
    final int[] colors = {Color.rgb(220,60,70), Color.rgb(50,110,220), Color.rgb(45,165,90), Color.rgb(235,175,35)};
    final String[] names = {"RED", "BLUE", "GREEN", "YELLOW"};
    final int[] starts = {0, 13, 26, 39};
    final int[] safe = {0,8,13,21,26,34,39,47};
    final int[][] route = {
        {6,1},{6,2},{6,3},{6,4},{6,5},{5,6},{4,6},{3,6},{2,6},{1,6},{0,6},{0,7},{0,8},
        {1,8},{2,8},{3,8},{4,8},{5,8},{6,9},{6,10},{6,11},{6,12},{6,13},{6,14},
        {7,14},{8,14},{8,13},{8,12},{8,11},{8,10},{8,9},{9,8},{10,8},{11,8},{12,8},{13,8},
        {14,8},{14,7},{14,6},{13,6},{12,6},{11,6},{10,6},{9,6},{8,5},{8,4},{8,3},{8,2},
        {8,1},{8,0},{7,0},{6,0}
    };
    final int[][][] lanes = {
        {{7,1},{7,2},{7,3},{7,4},{7,5},{7,6}},
        {{13,7},{12,7},{11,7},{10,7},{9,7},{8,7}},
        {{7,13},{7,12},{7,11},{7,10},{7,9},{7,8}},
        {{1,7},{2,7},{3,7},{4,7},{5,7},{6,7}}
    };

    public static void acceptTestDice(int value) {
        if (active != null && active.testMode && !active.gameOver) {
            pendingTestDice = value;
            active.status.setText("TEST DICE QUEUED: " + value + " • tap ROLL");
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        active = this;
        Arrays.fill(positions, -1);
        buildUi();
        updateUi();
    }

    void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(10), dp(12), dp(10)); root.setBackgroundColor(Color.rgb(248,249,252));
        TextView title = new TextView(this); title.setText("LUDO ARENA"); title.setTextSize(25); title.setTypeface(null,1);
        title.setTextColor(Color.rgb(30,40,60)); title.setGravity(Gravity.CENTER); root.addView(title, new LinearLayout.LayoutParams(-1,dp(42)));
        modeText = new TextView(this); modeText.setGravity(Gravity.CENTER); modeText.setTextSize(12); root.addView(modeText, new LinearLayout.LayoutParams(-1,dp(24)));
        board = new BoardView(this); root.addView(board, new LinearLayout.LayoutParams(-1,0,1));
        status = new TextView(this); status.setGravity(Gravity.CENTER); status.setTextSize(15); status.setTypeface(null,1);
        status.setTextColor(Color.rgb(30,40,60)); root.addView(status,new LinearLayout.LayoutParams(-1,dp(36)));
        diceText = new TextView(this); diceText.setGravity(Gravity.CENTER); diceText.setTextSize(20); diceText.setTypeface(null,1);
        root.addView(diceText,new LinearLayout.LayoutParams(-1,dp(36)));
        controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL); controls.setGravity(Gravity.CENTER);
        rollButton = new Button(this); rollButton.setText("ROLL DICE"); rollButton.setOnClickListener(v -> rollDice());
        controls.addView(rollButton,new LinearLayout.LayoutParams(0,dp(52),1));
        resetButton = new Button(this); resetButton.setText("NEW GAME"); resetButton.setOnClickListener(v -> resetGame());
        controls.addView(resetButton,new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(controls);
        modeButton = new Button(this); modeButton.setText("Enable Private Test Mode");
        modeButton.setOnClickListener(v -> {
            testMode = !testMode; pendingTestDice = 0;
            modeButton.setText(testMode ? "Disable Private Test Mode" : "Enable Private Test Mode");
            updateUi();
            Toast.makeText(this, testMode ? "Test mode ON: controller dice accepted" : "Test mode OFF: random dice only", Toast.LENGTH_LONG).show();
        });
        root.addView(modeButton,new LinearLayout.LayoutParams(-1,dp(46)));
        TextView hint = new TextView(this); hint.setText("Local pass-and-play • Tap a token after rolling • Test control only in private mode");
        hint.setTextSize(11); hint.setGravity(Gravity.CENTER); hint.setTextColor(Color.DKGRAY);
        root.addView(hint,new LinearLayout.LayoutParams(-1,dp(30)));
        setContentView(root);
    }

    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+0.5f); }

    void rollDice() {
        if (gameOver || rolled) return;
        dice = (testMode && pendingTestDice >= 1 && pendingTestDice <= 6) ? pendingTestDice : 1 + random.nextInt(6);
        pendingTestDice = 0;
        rolled = true;
        List<Integer> legal = legalTokens(currentPlayer, dice);
        diceText.setText("🎲 " + dice);
        if (legal.isEmpty()) {
            status.setText(names[currentPlayer] + " has no move");
            rolled = false;
            if (dice != 6) nextTurn(); else status.setText(names[currentPlayer] + " rolled 6 but no legal token");
            board.invalidate(); updateUi();
            return;
        }
        status.setText(names[currentPlayer] + " • choose a token");
        if (legal.size() == 1) status.setText(names[currentPlayer] + " • tap the highlighted token");
        board.invalidate(); updateUi();
    }

    List<Integer> legalTokens(int player, int value) {
        List<Integer> list = new ArrayList<>();
        for (int t=0;t<4;t++) {
            int pos=positions[player*4+t];
            if (pos==58) continue;
            if (pos==-1) { if (value==6) list.add(t); }
            else if (pos+value<=58) list.add(t);
        }
        return list;
    }

    void moveToken(int token) {
        if (!rolled || gameOver) return;
        List<Integer> legal=legalTokens(currentPlayer,dice);
        if (!legal.contains(token)) { Toast.makeText(this,"That token cannot move",Toast.LENGTH_SHORT).show(); return; }
        int idx=currentPlayer*4+token;
        int old=positions[idx];
        if (old==-1) positions[idx]=0;
        else positions[idx]=old+dice;
        boolean captured=false;
        if (positions[idx]>=0 && positions[idx]<=51) {
            int global=(starts[currentPlayer]+positions[idx])%52;
            if (!isSafe(global)) {
                for(int p=0;p<4;p++) if(p!=currentPlayer) for(int t=0;t<4;t++) {
                    int oi=p*4+t, op=positions[oi];
                    if(op>=0 && op<=51 && (starts[p]+op)%52==global) { positions[oi]=-1; captured=true; }
                }
            }
        }
        boolean won=true;
        for(int t=0;t<4;t++) if(positions[currentPlayer*4+t]!=58) won=false;
        rolled=false;
        if(won){ gameOver=true; status.setText("🏆 "+names[currentPlayer]+" WINS!"); }
        else if(dice==6 || captured) { status.setText(captured ? "Capture! " + names[currentPlayer] + " plays again" : "Six! " + names[currentPlayer] + " plays again"); }
        else nextTurn();
        board.invalidate(); updateUi();
    }

    boolean isSafe(int global){ for(int v:safe) if(v==global) return true; return false; }

    void nextTurn() {
        rolled=false;
        for(int i=1;i<=4;i++) {
            int p=(currentPlayer+i)%4;
            boolean all=true; for(int t=0;t<4;t++) if(positions[p*4+t]!=58) all=false;
            if(!all){currentPlayer=p;break;}
        }
    }

    void resetGame() {
        Arrays.fill(positions,-1); currentPlayer=0; dice=1; rolled=false; gameOver=false; pendingTestDice=0;
        status.setText("RED starts • roll a 6 to enter"); diceText.setText("🎲 —"); board.invalidate(); updateUi();
    }

    void updateUi() {
        if (modeText != null) modeText.setText(testMode ? "PRIVATE TEST ROOM • CONTROLLER ENABLED" : "LOCAL PASS-AND-PLAY • RANDOM DICE");
        if (status != null && !gameOver && !rolled && !status.getText().toString().contains("no move")) status.setText(names[currentPlayer] + " turn • roll a 6 to leave home");
        if (diceText != null) diceText.setText("🎲 " + (rolled ? dice : "—"));
        if (rollButton != null) rollButton.setEnabled(!rolled && !gameOver);
        if (board != null) board.invalidate();
    }

    class BoardView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        BoardView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void fill(Canvas c,int color,float l,float t,float r,float b){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRect(l,t,r,b,p);}
        void cell(Canvas c,float s,int x,int y,int color){fill(c,color,x*s,y*s,(x+1)*s,(y+1)*s);p.setColor(Color.LTGRAY);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);c.drawRect(x*s,y*s,(x+1)*s,(y+1)*s,p);p.setStyle(Paint.Style.FILL);}
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float size=Math.min(getWidth(),getHeight()), s=size/15f, ox=(getWidth()-size)/2f, oy=(getHeight()-size)/2f;
            c.save();c.translate(ox,oy);
            fill(c,Color.WHITE,0,0,size,size);
            for(int y=0;y<15;y++)for(int x=0;x<15;x++)cell(c,s,x,y,Color.rgb(255,255,255));
            // home quadrants
            int[][] homes={{0,0},{9,0},{9,9},{0,9}};
            int[] hc={colors[0],colors[1],colors[2],colors[3]};
            for(int q=0;q<4;q++){
                int x=homes[q][0],y=homes[q][1]; fill(c,hc[q],x*s,y*s,(x+6)*s,(y+6)*s);
                p.setColor(Color.WHITE);p.setStyle(Paint.Style.FILL);c.drawRoundRect(x*s+s*.7f,y*s+s*.7f,(x+5.3f)*s,(y+5.3f)*s,s*.4f,s*.4f,p);
                for(int a=0;a<2;a++)for(int b=0;b<2;b++){p.setColor(hc[q]);c.drawCircle((x+1.8f+a*2.4f)*s,(y+1.8f+b*2.4f)*s,s*.48f,p);}
            }
            // track
            for(int i=0;i<route.length;i++){
                int x=route[i][0],y=route[i][1]; cell(c,s,x,y,Color.WHITE);
                if(i==starts[0])cell(c,s,x,y,colors[0]); if(i==starts[1])cell(c,s,x,y,colors[1]);
                if(i==starts[2])cell(c,s,x,y,colors[2]); if(i==starts[3])cell(c,s,x,y,colors[3]);
                if(isSafe(i)){p.setColor(Color.LTGRAY);p.setTextSize(s*.55f);p.setTextAlign(Paint.Align.CENTER);c.drawText("★",(x+.5f)*s,(y+.68f)*s,p);}
            }
            for(int pl=0;pl<4;pl++) for(int j=0;j<6;j++) cell(c,s,lanes[pl][j][0],lanes[pl][j][1],colors[pl]);
            // center
            fill(c,Color.rgb(240,240,245),6*s,6*s,9*s,9*s);
            p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(s*.6f);p.setColor(Color.DKGRAY);c.drawText("LUDO",(7.5f)*s,7.3f*s,p);
            p.setTextSize(s*.42f);c.drawText("ARENA",(7.5f)*s,8.05f*s,p);
            // tokens
            for(int pl=0;pl<4;pl++)for(int t=0;t<4;t++){
                int pos=positions[pl*4+t]; float cx,cy;
                if(pos==-1){int hx=(pl==0||pl==3)?0:9, hy=(pl==0||pl==1)?0:9; int a=t%2,b=t/2; cx=(hx+1.8f+a*2.4f)*s;cy=(hy+1.8f+b*2.4f)*s;}
                else if(pos<=51){int g=(starts[pl]+pos)%52;cx=(route[g][0]+.5f)*s;cy=(route[g][1]+.5f)*s;}
                else if(pos<=57){cx=(lanes[pl][pos-52][0]+.5f)*s;cy=(lanes[pl][pos-52][1]+.5f)*s;}
                else {cx=(7.5f+(t%2)*.25f)*s;cy=(7.5f+(t/2)*.25f)*s;}
                p.setColor(Color.BLACK);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(s*.07f);c.drawCircle(cx,cy,s*.34f,p);
                p.setStyle(Paint.Style.FILL);p.setColor(colors[pl]);c.drawCircle(cx,cy,s*.30f,p);
                p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(s*.32f);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText(""+(t+1),cx,cy+s*.11f,p);
            }
            c.restore();
        }
        public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            if(!rolled || gameOver)return true;
            float size=Math.min(getWidth(),getHeight()),s=size/15f,ox=(getWidth()-size)/2f,oy=(getHeight()-size)/2f;
            float x=(e.getX()-ox)/s,y=(e.getY()-oy)/s;
            List<Integer> legal=legalTokens(currentPlayer,dice);
            for(int t:legal){
                int pos=positions[currentPlayer*4+t];float cx,cy;
                if(pos==-1){int pl=currentPlayer,hx=(pl==0||pl==3)?0:9,hy=(pl==0||pl==1)?0:9;cx=hx+1.8f+(t%2)*2.4f;cy=hy+1.8f+(t/2)*2.4f;}
                else if(pos<=51){int g=(starts[currentPlayer]+pos)%52;cx=route[g][0]+.5f;cy=route[g][1]+.5f;}
                else {cx=lanes[currentPlayer][pos-52][0]+.5f;cy=lanes[currentPlayer][pos-52][1]+.5f;}
                if(Math.hypot(x-cx,y-cy)<.8){moveToken(t);return true;}
            }
            Toast.makeText(MainActivity.this,"Tap one of the current player's tokens",Toast.LENGTH_SHORT).show();return true;
        }
    }
}
