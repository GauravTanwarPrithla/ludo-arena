package com.ludoarena.player;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class TestDiceReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        int value = intent.getIntExtra("dice_value", 0);
        if (value < 1 || value > 6) return;
        // The receiver is signature-protected and MainActivity only consumes this in test mode.
        MainActivity.acceptTestDice(value);
        Toast.makeText(context, "Test dice queued: " + value, Toast.LENGTH_SHORT).show();
    }
}
