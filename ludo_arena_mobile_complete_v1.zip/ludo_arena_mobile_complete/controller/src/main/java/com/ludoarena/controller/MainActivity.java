package com.ludoarena.controller;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    int selected=6;
    TextView status;
    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24); root.setBackgroundColor(Color.rgb(247,249,253));
        TextView title=new TextView(this); title.setText("LUDO ARENA\nCONTROLLER"); title.setTextSize(25); title.setTypeface(null,1);
        title.setTextColor(Color.rgb(35,45,70)); title.setGravity(Gravity.CENTER);
        root.addView(title,new LinearLayout.LayoutParams(-1,120));
        TextView note=new TextView(this); note.setText("PRIVATE / TEST MODE ONLY\\nOpen Ludo Arena and enable Private Test Mode first.");
        note.setGravity(Gravity.CENTER); note.setTextSize(15); note.setTextColor(Color.DKGRAY);
        root.addView(note,new LinearLayout.LayoutParams(-1,90));
        TextView label=new TextView(this); label.setText("Choose the next test dice"); label.setTextSize(18);label.setGravity(Gravity.CENTER);
        root.addView(label,new LinearLayout.LayoutParams(-1,55));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(3);
        for(int n=1;n<=6;n++){
            final int value=n; Button btn=new Button(this);btn.setText(""+n);btn.setTextSize(24);
            btn.setOnClickListener(v->{selected=value;status.setText("Selected test dice: "+selected);});
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=100;lp.columnSpec=GridLayout.spec((n-1)%3,1f);lp.rowSpec=GridLayout.spec((n-1)/3);grid.addView(btn,lp);
        }
        root.addView(grid,new LinearLayout.LayoutParams(-1,220));
        Button apply=new Button(this);apply.setText("QUEUE TEST DICE");
        apply.setOnClickListener(v->{
            Intent i=new Intent("com.ludoarena.player.TEST_DICE");
            i.setPackage("com.ludoarena.player");i.putExtra("dice_value",selected);
            sendBroadcast(i,"com.ludoarena.player.permission.CONTROL_TEST_GAME");
            status.setText("Sent test dice "+selected+". Keep Player app in Private Test Mode.");
        });
        root.addView(apply,new LinearLayout.LayoutParams(-1,60));
        status=new TextView(this);status.setText("Selected test dice: 6");status.setGravity(Gravity.CENTER);status.setTextSize(15);
        root.addView(status,new LinearLayout.LayoutParams(-1,70));
        TextView foot=new TextView(this);foot.setText("For transparent local testing only. Not for public/competitive games.");
        foot.setGravity(Gravity.CENTER);foot.setTextSize(12);foot.setTextColor(Color.DKGRAY);
        root.addView(foot,new LinearLayout.LayoutParams(-1,60));
        setContentView(root);
    }
}
